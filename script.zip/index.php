<?php

   if(isset($_POST['submit'])){
   require 'phpmailer/PHPMailerAutoload.php';
   $mail = new PHPMailer();
   $mail ->IsSmtp();
   $mail ->SMTPDebug = 0;
   $mail ->SMTPAuth = true;
   $mail ->SMTPSecure = 'ssl';
   $mail ->Host = "smtp.gmail.com";
   $mail ->Port = 465; // or 587
   $mail ->IsHTML(true);
   $mail ->Username = "yourmailaddress";
   $mail ->Password = "********";
   $mail ->SetFrom($_POST['email'],$_POST['name']);
   $mail ->AddAddress("Reciver Email");
   $mail ->addReplyTo($_POST['email'],$_POST['name']);
   $mail ->Subject = 'Form Submission: ' .$_POST['subject'];
   $mail ->Body= '<body style="background-color: whitesmoke;padding: 30px;">
   <div style="width:700px;height: auto; background-color: rgb(255, 254, 254);font-family: Cambria, Cochin, Georgia, Times, serif;">
       <p style="margin-top: 35px; padding: 20px;text-align: center; color: rgb(50, 143, 205); margin-right: 20px;"> IP Address - <a href="https://www.ip2location.com/' . $ip_address . '"
               style="color: rgb(0, 153, 255); text-decoration: none;"><strong> ' . $ip_address . ' </strong></a><small
               style="color:rgb(255, 60, 0); padding-left:10px"> Click IP Address to see info</small></p>
       <table style="padding: 20px;font-size:20px;">
           <tr>
               <td style="width: 150px;padding: 10px;">Name - </td>
               <td>' . $name . '</td>
           </tr>
           <tr>
               <td style="width: 150px;padding: 10px;">Email Address - </td>
               <td>' . $email . '</td>
           </tr>
           <tr>
               <td style="width: 150px;padding: 10px;">Subject - </td>
               <td>' . $subject . '</td>
           </tr>
           <tr>
               <td style="width: 150px;padding: 10px;">Phone - </td>
               <td>' . $phone . '</td>
           </tr>
           <tr>
               <td style="width: 150px;padding: 10px;">Message - </td>
               <td>' . $message . '</td>
           </tr>
       </table>

   </div>

    </body>';



   if(!$mail->Send())
   {
        $msg = "<div class='alert alert-danger alert-dismissible fade show text-center' role='alert'>Message Sending Failed <i class='fa fa-times'> </i> <br> Message Sending Failed Due Technical Problem Resend The Message 
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
        <span aria-hidden='true'>&times;</span></button></div>";
    } 
  else 
    {
        $msg = "<div class='alert alert-success alert-dismissible fade show text-center' role='alert'>Message Sent <i class='fa fa-check-circle'> </i> <br> Thank You <strong>" . $name . "</strong> For Contacting Us. We'll Contact you in Couple of hours.
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
        <span aria-hidden='true'>&times;</span></button></div>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Send Script</title>
</head>
<body>
<form action="" method="POST">

<?php $msg;?>

    <input type="text" name="name" placeholder="Your Name">
    <br>
    <input type="text" name="email" placeholder="Your Email">
    <br>
    <input type="text" name="subject" placeholder="Your Subject">
    <br>
    <input type="text" name="phone" placeholder="Your Phone">
    <br>
    <textarea name="message" cols="30" rows="5" placeholder="Message"></textarea>
    <br>
    <input type="submit" name="subject" value="Subject">
</form>

    
</body>
</html>